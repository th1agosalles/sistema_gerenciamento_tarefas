package br.com.criandoapi.projeto.DAO;

import org.springframework.data.repository.CrudRepository;

import br.com.criandoapi.projeto.model.Tarefa;

public interface ITarefa extends CrudRepository<Tarefa, Integer>{

}
